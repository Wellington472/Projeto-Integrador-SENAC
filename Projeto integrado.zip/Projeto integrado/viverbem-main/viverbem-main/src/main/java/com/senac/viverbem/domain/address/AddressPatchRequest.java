package com.senac.viverbem.domain.address;

public class AddressPatchRequest {
    public String path;
    public String value;

}
