package com.senac.viverbem.domain.activity;

public class ActivityPatchRequest {

    public String path;
    public String value;
}
