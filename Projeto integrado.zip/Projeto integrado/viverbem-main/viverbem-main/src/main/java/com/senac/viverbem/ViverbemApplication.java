package com.senac.viverbem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ViverbemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ViverbemApplication.class, args);
	}

}
