package com.senac.viverbem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViverbemApplicationTests {

	@Test
	void contextLoads() {
	}

}
